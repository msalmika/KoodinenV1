﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KoodinenV1.Models
{
    public class ProfiiliViewModel
    {
        public string Nimi { get; set; }
        public DateTime? SuoritusPVM { get; set; }
        public int KurssiId { get; set; }
        //public string Kuvaus { get; set; }

    }
}
