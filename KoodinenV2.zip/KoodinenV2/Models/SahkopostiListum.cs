﻿using System;
using System.Collections.Generic;

#nullable disable

namespace KoodinenV1.Models
{
    public partial class SahkopostiListum
    {
        public string Email { get; set; }
    }
}
