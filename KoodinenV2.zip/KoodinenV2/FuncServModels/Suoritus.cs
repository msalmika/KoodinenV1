﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KoodinenV1.FuncServModels
{
    public class Suoritus
    {
        public string email { get; set; }
        public int tehtavaid { get; set; }

    }
}
